#!/bin/bash
git add .
git commit -m "$1"
#uencode ../sharehouse.zip latest.zip | sendmail -f felixb@gmail.com felixb@gmail.com
