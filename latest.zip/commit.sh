#!/bin/bash
git add .
echo "Subject: Latest commit SharehouseGame\r\n\r\n" >| ./commit.msg
git commit -m "$1" >> ./commit.msg
git archive --format=zip HEAD >| ./latest.zip
uuencode ./latest.zip latest.zip >> ./commit.msg
cat commit.msg | sendmail -f felixb@gmail.com felixb@gmail.com
rm commit.msg
